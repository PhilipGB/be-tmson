module.exports = [
  {
    token_id: 1,
    task_id: 1,
    transaction_time: new Date(2022, 1, 18, 0, 0),
    previous_transaction: null,
  },
  {
    token_id: 2,
    task_id: 2,
    transaction_time: new Date(2022, 1, 18, 1, 0),
    previous_transaction: null,
  },
];
