module.exports = [
  {
    slug: "language",
    description: "Teach a foreign language",
  },
];
