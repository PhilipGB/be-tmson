module.exports = [
  {
    task_id: 1,
    rating: 9,
    comment: "Good",
  },
  {
    task_id: 2,
    rating: 10,
    comment: "Great",
  },
];
