module.exports = [
  {
    username: "PhilipGB",
    first_name: "Philip",
    last_name: "Burgess",
    birth_date: new Date(1983, 0, 1),
    avatar_url:
      "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png",
    address: "West One, 100 Wellington St, Leeds",
    postcode: "LS14LT",
    email_address: "me@mine.com",
    bio: "Ullamco dolor ea ex consequat nostrud fugiat elit minim mollit aliqua incididunt cupidatat.",
    minter: true,
  },
  {
    username: "Leah",
    first_name: "Leah",
    last_name: "",
    birth_date: new Date(2000, 0, 1),
    avatar_url:
      "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png",
    address: "West One, 100 Wellington St, Leeds",
    postcode: "LS14LT",
    email_address: "me@mine.com",
    bio: "Ullamco dolor ea ex consequat nostrud fugiat elit minim mollit aliqua incididunt cupidatat.",
    minter: true,
  },
];
