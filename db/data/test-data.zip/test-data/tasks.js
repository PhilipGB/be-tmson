module.exports = [
  {
    booker_id: 1,
    provider_id: 2,
    skill_id: 1,
    start_time: new Date(2022, 1, 17, 19, 0),
    end_time: new Date(2022, 1, 17, 20, 0),
    location: "Zoom",
  },
  {
    booker_id: 2,
    provider_id: 1,
    skill_id: 2,
    start_time: new Date(2022, 1, 17, 20, 0),
    end_time: new Date(2022, 1, 17, 21, 0),
    location: "Zoom",
  },
];
