module.exports = [
  {
    token_id: 1,
    generated_date: new Date(2022, 1, 17, 0, 0),
    owner_id: 1,
    minter_id: 2,
  },
  {
    token_id: 2,
    generated_date: new Date(2022, 1, 17, 0, 0),
    owner_id: 2,
    minter_id: 1,
  },
];
