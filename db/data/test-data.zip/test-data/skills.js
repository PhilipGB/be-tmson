module.exports = [
  {
    skill_category: "language",
    skill_subcategory: "French",
    skill_description:
      "Teach French speaking and listening to English speakers",
    thumbnail_image_url:
      "https://dceff.org/wp-content/uploads/2014/11/french-flag-large.png",
  },
  {
    skill_category: "language",
    skill_subcategory: "German",
    skill_description:
      "Teach German speaking and listening to English speakers",
    thumbnail_image_url:
      "https://images.all-free-download.com/images/graphiclarge/german_flag_deutsche_272635.jpg",
  },
];
