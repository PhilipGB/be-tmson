module.exports = [
  {
    user_id: 1,
    skill_id: 1,
  },
  {
    user_id: 2,
    skill_id: 2,
  },
];
